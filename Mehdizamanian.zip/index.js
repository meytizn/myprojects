const navabar = document.getElementById("navbar")
const btnthem = document.getElementById("btnthem")


let color_list = ['red', 'blue', 'green', 'yellow']
let counter = 0
console.log(counter)
console.log(color_list)
console.log(color_list.length)

btnthem.addEventListener('click', function navcolor() {
  counter += 1;
  console.log(counter)
  navabar.style.backgroundColor = color_list[counter]
  if (counter === color_list.length - 1) {
    // alert('no color else');
    counter = -1
  }

})





